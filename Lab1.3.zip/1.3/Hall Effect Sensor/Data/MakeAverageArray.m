function Result = MakeAverageArray(data,filename)
    ArraySize = size(data,1)/500;
    data = data.';
    Result = zeros(2,ArraySize);
    for i = 0:ArraySize-1
        Result(1,i+1) = AverageCalculator(data,(i*500)+1,(i*500)+500);
        Result(2,i+1) = data(1,(i*500)+1);
    end
    save(filename,"Result");
end