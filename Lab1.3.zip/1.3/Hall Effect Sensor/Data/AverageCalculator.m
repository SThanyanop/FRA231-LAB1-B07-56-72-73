function Average = AverageCalculator(data,first,last)
    Average = sum(data(2,first:last))/500;
end