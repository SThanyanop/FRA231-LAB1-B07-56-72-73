function GraphPlot(varargin)
    x_label_name = varargin{nargin-2};
    y_label_name = varargin{nargin-1};

    Property = varargin{nargin};

    Parameter_Name = varargin{nargin-3};
    Reverse = varargin{nargin-5};
    Error = varargin{nargin-4};
    
    Data = varargin{1};

    Size = size(Data,2);   

    title_name = Parameter_Name{1};

    for i = 2:Size
        title_name = title_name + " VS ";
        title_name = title_name + Parameter_Name{i};
    end
   
    figure;
    hold on;
    
    for i = 1:Size
        
        TMP = Data{i};

        x_axis = TMP(2,:);
        if Reverse(i)
            y_axis = fliplr(TMP(1,:));
        else
            y_axis = TMP(1,:);
        end
        Graph = plot(x_axis,y_axis,Property{1,i},Color=Property{2,i},LineWidth=str2double(Property{3,i}));
        err = Error(i);
        if err > 0
            errorbar(x_axis,y_axis,err,Property{2,i});
        end
        Graph.DataTipTemplate.DataTipRows(1).Label = x_label_name + " : ";
        Graph.DataTipTemplate.DataTipRows(2).Label = y_label_name + " : ";
        Graph.DataTipTemplate.DataTipRows(4).Label = Parameter_Name{i};
    end
    hold off;
    legend(Parameter_Name,'Location','northwest');
    title(title_name);
    xlabel(x_label_name);
    ylabel(y_label_name);
    grid minor;
end