/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: QEI_Read.c
 *
 * Code generated for Simulink model 'QEI_Read'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Tue Oct 29 15:21:18 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "QEI_Read.h"
#include "rtwtypes.h"
#include "QEI_Read_private.h"

/* Block signals (default storage) */
B_QEI_Read_T QEI_Read_B;

/* Block states (default storage) */
DW_QEI_Read_T QEI_Read_DW;

/* Real-time model */
static RT_MODEL_QEI_Read_T QEI_Read_M_;
RT_MODEL_QEI_Read_T *const QEI_Read_M = &QEI_Read_M_;

/* Model step function */
void QEI_Read_step(void)
{
  int32_T tmp;
  int32_T tmp_0;
  uint32_T pinReadLoc;
  boolean_T tmp_1;

  /* MATLABSystem: '<S7>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOB);

  /* MATLABSystem: '<S7>/Digital Port Read' */
  QEI_Read_B.DigitalPortRead_d = ((pinReadLoc & 16U) != 0U);

  /* MATLABSystem: '<S9>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOB);

  /* MATLABSystem: '<S9>/Digital Port Read' */
  QEI_Read_B.DigitalPortRead = ((pinReadLoc & 32U) != 0U);

  /* MATLAB Function: '<Root>/Polling x2' incorporates:
   *  MATLAB Function: '<Root>/Polling x1'
   *  MATLAB Function: '<Root>/Polling x4'
   */
  tmp = QEI_Read_B.DigitalPortRead_d - QEI_Read_B.DigitalPortRead;
  if ((tmp == -1) && (QEI_Read_DW.trig != 0.0)) {
    QEI_Read_DW.pos_a++;
    QEI_Read_DW.trig = 0.0;
  } else if ((tmp == 1) && (QEI_Read_DW.trig != 0.0)) {
    QEI_Read_DW.pos_a--;
    QEI_Read_DW.trig = 0.0;
  }

  if ((tmp == -1) && (QEI_Read_DW.trig == 0.0)) {
    QEI_Read_DW.pos_a++;
    QEI_Read_DW.trig = -1.0;
  } else if ((tmp == 1) && (QEI_Read_DW.trig == 0.0)) {
    QEI_Read_DW.pos_a--;
    QEI_Read_DW.trig = -1.0;
  }

  tmp_1 = (QEI_Read_B.DigitalPortRead_d && QEI_Read_B.DigitalPortRead);
  if (tmp_1) {
    QEI_Read_DW.trig = 1.0;
  }

  QEI_Read_B.P_g = QEI_Read_DW.pos_a;

  /* End of MATLAB Function: '<Root>/Polling x2' */
  /* MATLAB Function: '<Root>/Polling x4' */
  if ((tmp == -1) && (QEI_Read_DW.trigA != 0.0)) {
    QEI_Read_DW.pos++;
    QEI_Read_DW.trigA = 0.0;
  } else if ((tmp == 1) && (QEI_Read_DW.trigA != 0.0)) {
    QEI_Read_DW.pos--;
    QEI_Read_DW.trigA = 0.0;
  }

  if ((tmp == -1) && (QEI_Read_DW.trigA == 0.0)) {
    QEI_Read_DW.pos++;
    QEI_Read_DW.trigA = -1.0;
  } else if ((tmp == 1) && (QEI_Read_DW.trigA == 0.0)) {
    QEI_Read_DW.pos--;
    QEI_Read_DW.trigA = -1.0;
  }

  tmp_0 = QEI_Read_B.DigitalPortRead - QEI_Read_B.DigitalPortRead_d;
  if ((tmp_0 == 1) && (QEI_Read_DW.trigB != 0.0)) {
    QEI_Read_DW.pos++;
    QEI_Read_DW.trigB = 0.0;
  } else if ((tmp_0 == -1) && (QEI_Read_DW.trigB != 0.0)) {
    QEI_Read_DW.pos--;
    QEI_Read_DW.trigB = 0.0;
  }

  if ((tmp_0 == 1) && (QEI_Read_DW.trigB == 0.0)) {
    QEI_Read_DW.pos++;
    QEI_Read_DW.trigB = -1.0;
  } else if ((tmp_0 == -1) && (QEI_Read_DW.trigB == 0.0)) {
    QEI_Read_DW.pos--;
    QEI_Read_DW.trigB = -1.0;
  }

  if (tmp_1) {
    QEI_Read_DW.trigA = 1.0;
    QEI_Read_DW.trigB = 1.0;
  }

  QEI_Read_B.P = QEI_Read_DW.pos;

  /* MATLAB Function: '<Root>/Polling x1' */
  if ((tmp == -1) && (QEI_Read_DW.trig_i != 0.0)) {
    QEI_Read_DW.pos_j++;
    QEI_Read_DW.trig_i = 0.0;
  } else if ((tmp == 1) && (QEI_Read_DW.trig_i != 0.0)) {
    QEI_Read_DW.pos_j--;
    QEI_Read_DW.trig_i = 0.0;
  }

  if (tmp_1) {
    QEI_Read_DW.trig_i = 1.0;
  }

  QEI_Read_B.P_n = QEI_Read_DW.pos_j;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  QEI_Read_M->Timing.taskTime0 =
    ((time_T)(++QEI_Read_M->Timing.clockTick0)) * QEI_Read_M->Timing.stepSize0;
}

/* Model initialize function */
void QEI_Read_initialize(void)
{
  /* Registration code */
  rtmSetTFinal(QEI_Read_M, -1);
  QEI_Read_M->Timing.stepSize0 = 0.1;

  /* External mode info */
  QEI_Read_M->Sizes.checksums[0] = (3595602356U);
  QEI_Read_M->Sizes.checksums[1] = (975071838U);
  QEI_Read_M->Sizes.checksums[2] = (963207192U);
  QEI_Read_M->Sizes.checksums[3] = (784611742U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[6];
    QEI_Read_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(QEI_Read_M->extModeInfo,
      &QEI_Read_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(QEI_Read_M->extModeInfo, QEI_Read_M->Sizes.checksums);
    rteiSetTPtr(QEI_Read_M->extModeInfo, rtmGetTPtr(QEI_Read_M));
  }

  /* SystemInitialize for MATLAB Function: '<Root>/Polling x2' */
  QEI_Read_DW.trig = 1.0;

  /* SystemInitialize for MATLAB Function: '<Root>/Polling x4' */
  QEI_Read_DW.trigA = 1.0;
  QEI_Read_DW.trigB = 1.0;

  /* SystemInitialize for MATLAB Function: '<Root>/Polling x1' */
  QEI_Read_DW.trig_i = 1.0;
}

/* Model terminate function */
void QEI_Read_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
