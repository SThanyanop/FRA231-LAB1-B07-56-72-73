function B = FluxDensityCal(Vout,Vq,sensitivity,Stc,Ta)
   Divisor = Vout - Vq;
   Denominator = sensitivity * (1 + (Stc * (Ta - 25)));
   B = Divisor/Denominator;
end

