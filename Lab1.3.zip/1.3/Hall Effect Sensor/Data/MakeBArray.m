function res = MakeBArray(data,Vq,sensitivity,Stc,Ta)
    Btmp = [];
    dis = [];
    for i = 1:size(data,2)
        Vout = data(1,i) * 1000;
        Btmp(end+1) = FluxDensityCal(Vout,Vq,sensitivity,Stc,Ta);
        dis(end+1) = data(2,i);
    end
    MDS = [Btmp;dis];
    res = MDS;
end

