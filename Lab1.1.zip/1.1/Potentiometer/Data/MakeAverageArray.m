
function AverageArray = MakeAverageArray(data,filename)
    ArraySize = size(data,1) / 500;
    data = data.';
    AverageArray = zeros(2,ArraySize);
    for i = 0:ArraySize-1
        AverageArray(1,i+1) = calculateAverage(data,(i*500)+1,(i*500)+500);
        AverageArray(2,i+1) = data(2,(i*500)+1);
    end
    save(filename,"AverageArray");
end