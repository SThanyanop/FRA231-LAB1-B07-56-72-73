function CompareData(d1,d2,dim)
    Size = numel(d1)/2;
    p5 = 0;

    for i = 2:Size
        p1 = d1(1,i);
        p2 = d2(1,i);
        p3 = abs(p2 - p1);
        p4 = 100 - p3;
        if p4 < 80
            p4 = 0;
        end
        p4 = p4/100;
        p5 = p5 + p4;
    end
    result = 2.5 * p5;

    Dim = dim;
    str = {'Macth (%) : ',num2str(result)};
    annotation('textbox',dim,'String',str,'FitBoxToText','on');

end