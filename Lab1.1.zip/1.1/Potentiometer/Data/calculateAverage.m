function Average = calculateAverage(data,first,last)
    data = data.';
    Average = sum(data(first:last))/500;
end